# @babel/helper-module-imports

> Babel helper functions for inserting module loads

See our website [@babel/helper-module-imports](https://babeljs.io/docs/en/babel-helper-module-imports) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-module-imports
```

or using yarn:

```sh
yarn add @babel/helper-module-imports
```
