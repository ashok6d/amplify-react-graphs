# @babel/plugin-transform-template-literals

> Compile ES2015 template literals to ES5

See our website [@babel/plugin-transform-template-literals](https://babeljs.io/docs/en/babel-plugin-transform-template-literals) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-transform-template-literals
```

or using yarn:

```sh
yarn add @babel/plugin-transform-template-literals --dev
```
