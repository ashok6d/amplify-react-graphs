module.exports = require("./data/plugins.json");
